<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
 <ul>
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li><?php echo e($error); ?></li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </ul>
</div>
<?php endif; ?>
<style>
        .container{
            padding:0.5%;
        }
    </style>
<div class="container">
<h2 class="alert alert-success text-center color:red">WELCOME!! CREATE YOUR NEW EMPLOYEE HERE</h2>
</div>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

<form method="post" action="<?php echo e(route('employee.store')); ?>" enctype="multipart/form-data">

 <?php echo csrf_field(); ?>

<!-- Extended default form grid -->
<form>
  <!-- Grid row -->
  <div class="form-row">
    <!-- Default input -->
    <div class="form-group col-md-6">
      <input mdbInput type="text" class="form-control" name="first_name" id="first_name" placeholder="First Name">
    </div>
    <!-- Default input -->
    <div class="form-group col-md-6">
      <input mdbInput type="text" class="form-control" name="last_name" id="last_name" placeholder="Last Name">
    </div>

  <!-- Default input -->
  <div class="form-group col-md-6">
    <input mdbInput type="text" class="form-control" name="gender" id="gender" placeholder="Gender">
  </div>
  <!-- Default input -->
  <div class="form-group col-md-6">
    <input mdbInput type="email" class="form-control" name="email" id="email" placeholder="Email">
  </div>
    <!-- Default input -->
    <div class="form-group col-md-6">
      <input mdbInput type="text" class="form-control" name="phone" id="phone" placeholder="(+) Phone">
    </div>
    <div class="form-group col-md-3">
        <input type="file" name="image" id="image" class="form-control">
    </div>
  </div>
  <!-- Grid row -->
 <a href="<?php echo e(route('employee.index')); ?>" class="btn btn-warning">Cancel</a>
 <button type="submit"  name="add" class="btn btn-info input-lg">Create Employee</button>
</form>
<!-- Extended default form grid -->
</div>
 </div>
</form>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
 //---------------------Browse image----------------
 $('#browse_file').on('click',function(){
                            $('#image').click();                 
                        })
                        $('#image').on('change', function(e){
                            showFile(this, '#showImage');
                        })

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\xampp\laravel1\B00353773-Advance-Crud-upload\resources\views/create.blade.php ENDPATH**/ ?>