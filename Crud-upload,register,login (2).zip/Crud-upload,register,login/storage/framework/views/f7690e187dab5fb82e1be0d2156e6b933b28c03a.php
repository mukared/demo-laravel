<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
 <ul>
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li><?php echo e($error); ?></li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </ul>
</div>
<?php endif; ?>
<style>
        .container{
            padding:0.5%;
        }
    </style>
<div class="container">
<h2 class="alert alert-dark text-center " style="color:red; text:bold"><span class="fab fa-laravel"> B00353773 CRUD APPLICATION WITH IMAGE UPLOAD</span></h2>
<br>
<h2 class="alert alert-success " > EDIT EMPLOYEE #<?php echo e($data->id); ?> <span class="fa fa-user" style="float:right"> <?php echo e($data->first_name); ?>  <?php echo e($data->last_name); ?></span> </h2>
</div>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

<form method="post" action="<?php echo e(route('employee.update', $data->id)); ?>" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>
<!-- Extended default form grid -->
<form>
  <!-- Grid row -->
  <div class="form-row">
    <!-- Default input -->
    <div class="form-group col-md-6">
      <input mdbInput type="text" class="form-control" name="first_name" id="first_name" value="<?php echo e($data->first_name); ?>" placeholder="First Name">
    </div>
    <!-- Default input -->
    <div class="form-group col-md-6">
      <input mdbInput type="text" class="form-control" name="last_name" id="last_name" value="<?php echo e($data->last_name); ?>" placeholder="Last Name">
    </div>

  <!-- Default input -->
  <div class="form-group col-md-6">
    <input mdbInput type="text" class="form-control" name="gender" id="gender" value="<?php echo e($data->gender); ?>" placeholder="Gender">
  </div>
  <!-- Default input -->
  <div class="form-group col-md-6">
    <input mdbInput type="email" class="form-control" name="email" id="email" value="<?php echo e($data->email); ?>" placeholder="Email">
  </div>
    <!-- Default input -->
    <div class="form-group col-md-6">
      <input mdbInput type="text" class="form-control" name="phone" id="phone" value="<?php echo e($data->phone); ?>" placeholder="(+) Phone">
    </div>
    <div class="row">
    <div class="form-group col-md-4">
        <input type="file" name="image" id="image" class="form-control">
        </div>
    <div class="form-group col-md-3">
        <img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($data->image); ?>" class="rounded-circle" width="60" />
        <input type="hidden" name="hidden_image" value="<?php echo e($data->image); ?>" />
    </div>
    </div>
  </div>
  <!-- Grid row -->
 <a href="<?php echo e(route('employee.index')); ?>" class="btn btn-warning">Cancel</a>
 <button type="submit"  name="add" class="btn btn-info input-lg">Create Employee</button>
</form>
<!-- Extended default form grid -->
</div>
 </div>
</form>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
 //---------------------Browse image----------------
 $('#browse_file').on('click',function(){
                            $('#image').click();                 
                        })
                        $('#image').on('change', function(e){
                            showFile(this, '#showImage');
                        })

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\xampp\laravel1\B00353773-Advance-Crud-upload\resources\views/edit.blade.php ENDPATH**/ ?>