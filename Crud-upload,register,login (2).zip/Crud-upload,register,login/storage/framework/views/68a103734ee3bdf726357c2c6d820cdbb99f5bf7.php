<?php $__env->startSection('content'); ?>

<style>
        .container{
            padding:0.5%;
        }
    </style>
<div class="container">
<h2 class="alert alert-dark text-center " style="color:red; text:bold"><span class="fab fa-laravel"> B00353773 CRUD APPLICATION WITH IMAGE UPLOAD</span></h2>

<?php if($message = Session::get('Success')): ?>
<div class="alert alert-success">
<p align="center"><?php echo e($message); ?></p>
</div>
<?php endif; ?>

<?php if($message = Session::get('error')): ?>
<div class="alert alert-danger">
<p align="center"><?php echo e($message); ?></p>
</div>
<?php endif; ?>

</div>
<div align="right">
 <a href="<?php echo e(route('employee.create')); ?>" class="btn btn-default">
 <span class="fa fa-plus-circle"> Add New Employee</span></a>
</div>
<table class="table table-bordered table-striped bg-dark" style="color:white; border:none">
 <tr class="text-center">
  <th width="10%">Image</th>
  <th >First Name</th>
  <th >Last Name</th>
  <th >Gender</th>
  <th >Email</th>
  <th >Phone</th>
  <th >Action</th>
 </tr>
 <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <tbody style="color:black; font:blod; background:#ffff">
  <tr class="text-center">
   <td><img src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($employee->image); ?>" class="rounded-circle" width="60" height="50" /></td>
   <td><?php echo e($employee->first_name); ?></td>
   <td><?php echo e($employee->last_name); ?></td>
   <td><?php echo e($employee->gender); ?></td>
   <td><?php echo e($employee->email); ?></td>
   <td><?php echo e($employee->phone); ?></td>
   <td width="25%">
   <!-- here is the button action side where you can edit . view and delete the employee record -->
   <form action="<?php echo e(route('employee.destroy', $employee->id)); ?>" method="post">
	<a href="<?php echo e(route('employee.show', $employee->id)); ?>" class="btn btn-sm btn-warning"><span class="fa fa-eye"></span> Show</a>
	<a href="<?php echo e(route('employee.edit', $employee->id)); ?>" class="btn btn-sm btn-info"><span class="fa fa-edit"></span> Edit</a>
	<?php echo csrf_field(); ?>
	<?php echo method_field('DELETE'); ?>
	<button type="submit" class="btn btn-sm btn-danger"><span class="fa fa-trash"></span> Delete</button>
	</form>
                <!-- ends here -->
   </td>
  </tr>
  </tbody>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo $data->links(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\xampp\htdocs\laravel\Laravel-6.0-Advance-Crud-upload\resources\views/index.blade.php ENDPATH**/ ?>