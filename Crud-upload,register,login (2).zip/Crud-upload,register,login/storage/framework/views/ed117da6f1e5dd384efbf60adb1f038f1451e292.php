
<style type="text/css">
    .student-image{
            height: 160px;
            padding-left: 1px;
            padding-right: 1px;
            /* border: 1px solid #ccc; */
            background: #eee;
            width:140px;
            margin: 0 auto;
            border-radius: 50%;
            vertical-align: middle;
    }

    .image > input[type='file']{
        display: none;
    }

    .image{
    vertical-align: middle;
    width: 50px;
    height: 50px;
    border-radius: 50%;
    }

    .student-id{

        background-repeat: repeat-x;
        /* border-color: #ccc; */
        padding: 5px;
        text-align: center;
        background:#eee;
        /* border-bottom: 1px solid #ccc; */
    }

     .btn-browse{

        /* border-color: #ccc; */
        padding: 5px;
        text-align: center;
        background:green;
        border: none;
        color:white;
        /* border-top: 1px solid #ccc; */
        border-radius: 50%;
    }

    fieldset{
    margin-top: 5px;
    }

    fieldset legend{
            display: block;
            width: 100%;
            padding: 0;
            font-size: 15px;
            border: 0;
            line-height: inherit;
            color:#797979;
            border-bottom: 1px solid #e5e5e5;
    }
    </style><?php /**PATH C:\Users\User\Documents\xampp\laravel1\B00353773-Advance-Crud-upload\resources\views/layouts/style.blade.php ENDPATH**/ ?>